/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

/**
 *
 * @author Antivirus
 */
import Model.Pelicula;
import Model.PeliculaDAO;
import Vista.PeliculaVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * --- CONTROLADOR (Versión Gráfica) ---
 * Conecta la Vista (GUI) con el Modelo (DAO).
 * Escucha los eventos de la Vista (ej: clics de botón) y responde a ellos
 * actualizando el Modelo y la Vista según corresponda.
 */
public class PeliculaControl {
    private PeliculaDAO modelo;
    private PeliculaVista vista;

    public PeliculaControl(PeliculaDAO modelo, PeliculaVista vista) {
        this.modelo = modelo;
        this.vista = vista;

        // Añadir el "oyente" (listener) al botón de la vista
        this.vista.addAgregarListener(new AgregarListener());
        
        // Cargar la lista inicial de películas al arrancar
        actualizarListaDePeliculas();
    }

    // Clase interna para manejar el evento del botón "Agregar"
    class AgregarListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                // 1. Obtiene los datos de la Vista
                String titulo = vista.getTitulo();
                String director = vista.getDirector();
                String genero = vista.getGenero();
                int anio = Integer.parseInt(vista.getAnio());

                // Validación simple (podría ser más compleja)
                if (titulo.isEmpty() || director.isEmpty()) {
                    vista.mostrarMensaje("El título y el director no pueden estar vacíos.");
                    return;
                }

                // 2. Crea un nuevo objeto Modelo
                Pelicula nuevaPelicula = new Pelicula(titulo, director, genero, anio);
                
                // 3. Envía el objeto al Modelo (DAO) para que lo guarde
                modelo.agregarPelicula(nuevaPelicula);
                
                // 4. Actualiza la Vista
                vista.mostrarMensaje("¡Película agregada con éxito!");
                vista.limpiarCampos();
                actualizarListaDePeliculas();

            } catch (NumberFormatException ex) {
                vista.mostrarMensaje("El año debe ser un número válido.");
            }
        }
    }

    private void actualizarListaDePeliculas() {
        // Pide la lista al modelo y se la pasa a la vista para que la muestre
        List<Pelicula> peliculas = modelo.obtenerTodasLasPeliculas();
        vista.mostrarPeliculas(peliculas);
    }
}
