/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Antivirus
 */
import java.util.ArrayList;
import java.util.List;

/**
 * --- MODELO (Capa de Persistencia) ---
 * DAO (Data Access Object)
 * Simula la persistencia de datos en memoria utilizando un ArrayList.
 * Gestiona las operaciones de CRUD (Crear, Leer, Actualizar, Borrar) sobre los objetos Pelicula.
 */
public class PeliculaDAO {
    private List<Pelicula> peliculas;

    public PeliculaDAO() {
        this.peliculas = new ArrayList<>();
    }

    // Método para AGREGAR una película a la lista
    public void agregarPelicula(Pelicula pelicula) {
        this.peliculas.add(pelicula);
    }

    // Método para CONSULTAR (obtener) todas las películas
    public List<Pelicula> obtenerTodasLasPeliculas() {
        return new ArrayList<>(this.peliculas); // Devuelve una copia para no modificar la lista original
    }
}