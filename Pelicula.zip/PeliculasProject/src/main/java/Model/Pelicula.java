/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Antivirus
 */
/**
 * --- MODELO ---
 * Representa una entidad de Película.
 * Contiene los datos y la lógica de negocio fundamental.
 */
public class Pelicula {
    // Atributos privados para encapsular los datos
    private String titulo;
    private String director;
    private String genero;
    private int anno;

    // Constructor para inicializar un objeto Pelicula
    public Pelicula(String titulo, String director, String genero, int anno) {
        this.titulo = titulo;
        this.director = director;
        this.genero = genero;
        this.anno = anno;
    }

    // Métodos públicos "getter" para obtener los valores de los atributos
    public String getTitulo() {
        return titulo;
    }

    public String getDirector() {
        return director;
    }

    public String getGenero() {
        return genero;
    }

    public int getAnio() {
        return anno;
    }

    // Métodos públicos "setter" para modificar los valores de los atributos
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setAnio(int anno) {
        this.anno = anno;
    }

    // Sobrescribimos el método toString() para mostrar la información del objeto fácilmente
    @Override
    public String toString() {
        return "Pelicula [Título: " + titulo + ", Director: " + director + ", Género: " + genero + ", Año: " + anno + "]";
    }
}