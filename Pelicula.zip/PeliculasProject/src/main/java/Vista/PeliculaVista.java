/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author Antivirus
 */
import Model.Pelicula;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * --- VISTA (Versión Gráfica) ---
 * Responsable de la interfaz gráfica de usuario (GUI) usando Swing.
 * Crea y organiza los componentes visuales.
 * No contiene lógica de negocio; su única tarea es mostrar datos y capturar la entrada del usuario.
 */
public class PeliculaVista extends JFrame {

    // Componentes de la interfaz
    private JTextField tituloField, directorField, generoField, anioField;
    private JButton agregarButton;
    private JTextArea listaPeliculasArea;

    public PeliculaVista() {
        // --- Configuración de la ventana principal ---
        setTitle("Gestor de Películas MVC");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar la ventana
        
        // --- Panel de entrada de datos ---
        JPanel panelEntrada = new JPanel(new GridLayout(5, 2, 5, 5)); // 5 filas, 2 columnas, con espaciado
        panelEntrada.setBorder(BorderFactory.createTitledBorder("Nueva Película"));

        tituloField = new JTextField();
        directorField = new JTextField();
        generoField = new JTextField();
        anioField = new JTextField();
        agregarButton = new JButton("Agregar Película");

        panelEntrada.add(new JLabel("Título:"));
        panelEntrada.add(tituloField);
        panelEntrada.add(new JLabel("Director:"));
        panelEntrada.add(directorField);
        panelEntrada.add(new JLabel("Género:"));
        panelEntrada.add(generoField);
        panelEntrada.add(new JLabel("Año:"));
        panelEntrada.add(anioField);
        panelEntrada.add(new JLabel()); // Espacio vacío
        panelEntrada.add(agregarButton);

        // --- Área de texto para mostrar la lista ---
        listaPeliculasArea = new JTextArea();
        listaPeliculasArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(listaPeliculasArea); // Para añadir barras de desplazamiento
        scrollPane.setBorder(BorderFactory.createTitledBorder("Películas Registradas"));

        // --- Añadir paneles a la ventana principal ---
        setLayout(new BorderLayout(10, 10));
        add(panelEntrada, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    // --- Métodos para que el Controlador interactúe con la Vista ---

    public String getTitulo() { return tituloField.getText(); }
    public String getDirector() { return directorField.getText(); }
    public String getGenero() { return generoField.getText(); }
    public String getAnio() { return anioField.getText(); }

    public void addAgregarListener(ActionListener listener) {
        agregarButton.addActionListener(listener);
    }

    public void mostrarPeliculas(List<Pelicula> peliculas) {
        listaPeliculasArea.setText(""); // Limpiar el área de texto
        if (peliculas.isEmpty()) {
            listaPeliculasArea.setText("No hay películas registradas.");
        } else {
            for (Pelicula p : peliculas) {
                listaPeliculasArea.append(p.toString() + "\n");
            }
        }
    }

    public void limpiarCampos() {
        tituloField.setText("");
        directorField.setText("");
        generoField.setText("");
        anioField.setText("");
    }
    
    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }
}