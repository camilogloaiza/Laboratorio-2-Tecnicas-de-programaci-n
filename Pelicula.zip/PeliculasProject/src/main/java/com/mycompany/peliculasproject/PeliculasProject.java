/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.peliculasproject;

/**
 *
 * @author Antivirus
 */
import Control.PeliculaControl;
import Model.PeliculaDAO;
import Vista.PeliculaVista;
import javax.swing.SwingUtilities;

/**
 * Clase principal que inicia la aplicación gráfica.
 */
public class PeliculasProject {
    public static void main(String[] args) {
        // Se asegura de que la GUI se cree y se muestre en el Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // 1. Crear el Modelo (DAO)
                PeliculaDAO dao = new PeliculaDAO();
                
                // 2. Crear la Vista (GUI)
                PeliculaVista vista = new PeliculaVista();
                
                // 3. Crear el Controlador que las une
                new PeliculaControl(dao, vista);
                
                // 4. Hacer visible la ventana
                vista.setVisible(true);
            }
        });
    }
}