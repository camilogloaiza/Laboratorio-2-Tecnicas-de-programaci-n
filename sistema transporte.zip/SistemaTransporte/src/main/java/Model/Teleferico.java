/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.SistemaTarifario;

/**
 *
 * @author Antivirus
 */
public class Teleferico implements SistemaTarifario{
    
    @Override
    public double calcularTarifa(double distancia) {
        double tarifa = 1000 + (500 * distancia);
        return tarifa;
    }

    @Override
    public void mostrarRuta() {
        System.out.println("Ruta de conexión veredal (tarifa variable, base $1000 COP)");
    }
    
}
